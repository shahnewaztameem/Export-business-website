<!--header-->
<?php include "includes/header.php";?>
<?php include "includes/db.php";?>

    <div id="middle">
        <div id="bodyFormat1" class="wrap">
            <div class="roundedImage">
                <div class="myTabs mc horizontal10154  hot">
                    <ul class="fo lsn m0px p0px">
                        <li id="tab1102_1-1-2">
                            <a href="#1102_1-1-2">Hot Products
                            </a>
                        </li>
                    </ul>
                    <p class="cb">
                    </p>
                    <div class="ic" id="1102_1-1-2">
                        <div class="slider">
                            <ul class=" bxslider10154 ">

                                <li class="ac">
                                    <p class="h large b mb5px">
                                        <a href="<?= BASE_URL;?>/product/316/multifunctional-computer-thermal-cutting-bag-making-machine.html" title="Thermal Cutting Bag Making Machine">Thermal Cutting Bag Making Machine
                                        </a>
                                    </p>
                                    <div class="imgFrame m0a bdr">
                                        <div class="imgFrame picBg dtc ac vam lh0">
                                            <a href="<?= BASE_URL;?>/product/316/multifunctional-computer-thermal-cutting-bag-making-machine.html" title="Thermal Cutting Bag Making Machine">
                                                <img src="<?= BASE_URL;?>/tpadmin/images/product_image/Multifunctional-Computer-Thermal-Cutting-Bag-Making-Machine.jpg" alt="Thermal Cutting Bag Making Machine" title="Thermal Cutting Bag Making Machine" />
                                            </a>
                                        </div>
                                    </div>
                                    <div class="p5px mb5px mt10px">
                                    </div>
                                    <div class="ma1px">
                                        <a class="buttonBig p5px15px" href="<?= BASE_URL;?>/product/316/multifunctional-computer-thermal-cutting-bag-making-machine.html">Read More
                                        </a>
                                    </div>
                                </li>

                                <li class="ac">
                                    <p class="h large b mb5px">
                                        <a href="<?= BASE_URL;?>/product/305/dyeing-and-finishing-auxillaries.html" title="Dyeing and Finishing Auxillaries">Dyeing and Finishing Auxillaries
                                        </a>
                                    </p>
                                    <div class="imgFrame m0a bdr">
                                        <div class="imgFrame picBg dtc ac vam lh0">
                                            <a href="<?= BASE_URL;?>/product/305/dyeing-and-finishing-auxillaries.html" title="Dyeing and Finishing Auxillaries">
                                                <img src="<?= BASE_URL;?>/tpadmin/images/product_image/Dyeing%20and%20Finishing%20Auxillaries.jpg" alt="Dyeing and Finishing Auxillaries" title="Dyeing and Finishing Auxillaries" />
                                            </a>
                                        </div>
                                    </div>
                                    <div class="p5px mb5px mt10px">
                                    </div>
                                    <div class="ma1px">
                                        <a class="buttonBig p5px15px" href="<?= BASE_URL;?>/product/305/dyeing-and-finishing-auxillaries.html">Read More
                                        </a>
                                    </div>
                                </li>

                                <li class="ac">
                                    <p class="h large b mb5px">
                                        <a href="<?= BASE_URL;?>/product/296/caustic-soda.html" title="Caustic Soda ">Caustic Soda
                                        </a>
                                    </p>
                                    <div class="imgFrame m0a bdr">
                                        <div class="imgFrame picBg dtc ac vam lh0">
                                            <a href="<?= BASE_URL;?>/product/296/caustic-soda.html" title="Caustic Soda ">
                                                <img src="<?= BASE_URL;?>/tpadmin/images/product_image/Caustic_Soda.jpg" alt="Caustic Soda " title="Caustic Soda " />
                                            </a>
                                        </div>
                                    </div>
                                    <div class="p5px mb5px mt10px">
                                    </div>
                                    <div class="ma1px">
                                        <a class="buttonBig p5px15px" href="product/296/caustic-soda.html">Read More
                                        </a>
                                    </div>
                                </li>

                                <li class="ac">
                                    <p class="h large b mb5px">
                                        <a href="<?= BASE_URL;?>/product/263/xylene-chemicals.html" title="Xylene Chemicals">Xylene Chemicals
                                        </a>
                                    </p>
                                    <div class="imgFrame m0a bdr">
                                        <div class="imgFrame picBg dtc ac vam lh0">
                                            <a href="<?= BASE_URL;?>/product/263/xylene-chemicals.html" title="Xylene Chemicals">
                                                <img src="<?= BASE_URL;?>/tpadmin/images/product_image/Xylene-solvent-min.jpg" alt="Xylene Chemicals" title="Xylene Chemicals" />
                                            </a>
                                        </div>
                                    </div>
                                    <div class="p5px mb5px mt10px">
                                    </div>
                                    <div class="ma1px">
                                        <a class="buttonBig p5px15px" href="product/263/xylene-chemicals.html">Read More
                                        </a>
                                    </div>
                                </li>

                                <li class="ac">
                                    <p class="h large b mb5px">
                                        <a href="<?= BASE_URL;?>/product/246/kraft-liner-paper.html" title="Kraft Liner Paper">Kraft Liner Paper
                                        </a>
                                    </p>
                                    <div class="imgFrame m0a bdr">
                                        <div class="imgFrame picBg dtc ac vam lh0">
                                            <a href="<?= BASE_URL;?>/product/246/kraft-liner-paper.html" title="Kraft Liner Paper">
                                                <img src="<?= BASE_URL;?>/tpadmin/images/product_image/Kraft-Liner-Paper.jpg" alt="Kraft Liner Paper" title="Kraft Liner Paper" />
                                            </a>
                                        </div>
                                    </div>
                                    <div class="p5px mb5px mt10px">
                                    </div>
                                    <div class="ma1px">
                                        <a class="buttonBig p5px15px" href="product/246/kraft-liner-paper.html">Read More
                                        </a>
                                    </div>
                                </li>

                                <li class="ac">
                                    <p class="h large b mb5px">
                                        <a href="<?= BASE_URL;?>/product/223/polypropylene-pp-films.html" title="Polypropylene PP Films">Polypropylene PP Films
                                        </a>
                                    </p>
                                    <div class="imgFrame m0a bdr">
                                        <div class="imgFrame picBg dtc ac vam lh0">
                                            <a href="<?= BASE_URL;?>/product/223/polypropylene-pp-films.html" title="Polypropylene PP Films">
                                                <img src="<?= BASE_URL;?>/tpadmin/images/product_image/POLYPROPYLENE_PP_FILM.jpg" alt="Polypropylene PP Films" title="Polypropylene PP Films" />
                                            </a>
                                        </div>
                                    </div>
                                    <div class="p5px mb5px mt10px">
                                    </div>
                                    <div class="ma1px">
                                        <a class="buttonBig p5px15px" href="product/223/polypropylene-pp-films.html">Read More
                                        </a>
                                    </div>
                                </li>

                                <li class="ac">
                                    <p class="h large b mb5px">
                                        <a href="<?= BASE_URL;?>/product/222/polypropylene-pp-injection.html" title="Polypropylene PP Injection">Polypropylene PP Injection
                                        </a>
                                    </p>
                                    <div class="imgFrame m0a bdr">
                                        <div class="imgFrame picBg dtc ac vam lh0">
                                            <a href="<?= BASE_URL;?>/product/222/polypropylene-pp-injection.html" title="Polypropylene PP Injection">
                                                <img src="<?= BASE_URL;?>/tpadmin/images/product_image/POLYPROPYLEN%20INJECTION.jpg" alt="Polypropylene PP Injection" title="Polypropylene PP Injection" />
                                            </a>
                                        </div>
                                    </div>
                                    <div class="p5px mb5px mt10px">
                                    </div>
                                    <div class="ma1px">
                                        <a class="buttonBig p5px15px" href="product/222/polypropylene-pp-injection.html">Read More
                                        </a>
                                    </div>
                                </li>

                                <li class="ac">
                                    <p class="h large b mb5px">
                                        <a href="<?= BASE_URL;?>/product/199/diamond-potatos.html" title="Diamond Potato">Diamond Potato
                                        </a>
                                    </p>
                                    <div class="imgFrame m0a bdr">
                                        <div class="imgFrame picBg dtc ac vam lh0">
                                            <a href="<?= BASE_URL;?>/product/199/diamond-potatos.html" title="Diamond Potato">
                                                <img src="<?= BASE_URL;?>/tpadmin/images/product_image/Daimon_Potatoes.jpg" alt="Diamond Potato" title="Diamond Potato" />
                                            </a>
                                        </div>
                                    </div>
                                    <div class="p5px mb5px mt10px">
                                    </div>
                                    <div class="ma1px">
                                        <a class="buttonBig p5px15px" href="product/199/diamond-potatos.html">Read More
                                        </a>
                                    </div>
                                </li>

                            </ul>
                        </div>
                    </div>
                    <script type="text/javascript">
                        $(document).ready(function() {
                            $('.bxslider10154').bxSlider({
                                mode: 'horizontal',
                                slideWidth: 200,
                                maxSlides: 4,
                                slideMargin: 20,
                                auto: true,
                                autoDirection: 'next',
                                moveSlides: 1,
                                pause: 2000,
                                pager: true,
                                pagerType: 'full',
                                autoControls: true,
                                controls: true,
                                autoHover: true,
                                speed: 2000
                            });
                        });
                    </script>
                </div>
            </div>
            <br class="lh2em" />
            <div class="row1 dt columns12">
                <div class="col-1 width38">
                    <div class="h1 xxlarge">
                        <h1>Trading House for Papers Plastic Chemical Textiles raw materials and Machineries
                        </h1>
                    </div>
                    <div class="welcome aj ls">
                        <p>
                            Mass Export World is trusted trading house having diversified business activities primarily engaged import of Pharmaceutical Raw Materials, Petrochemical, Textiles Basic and Axllaries Chemical, Paint Chemical, Industrial Chemical, Pharmaceuticals and Rubber, Paper and Paper Board, Wastes Paper, Sewing Thread, Sweaters Yarn, Packaging Machinery etc. Our Export items are Rice, Fresh Potato, Coconut, Spices, Sesame seeds, Nut and Seeds, Rice Bran, Agarwood Etc.</p>
                        <p>&nbsp;</p>

                        <p>
                            Our marketing goals are mainly devoted with respect to Pharmaceutical Raw Materials, Basic Chemicals, Papers, Plastic, Textiles raw materials and Machineries. We represent a good deal of worldwide reputed Manufacturers exclusively for selling out their quality goods here in Bangladesh found in the valued buyers.</p>
                        <b class="dif ml7px">
                            <a href="<?= BASE_URL;?>/company-profile">Read more...
                            </a>
                        </b>
                    </div>
                </div>
                
<!--                sidebar home-->
           <?php include "includes/sidebar_home.php"?>
           
            </div>
        </div>
    </div>
    <br />

<!--footer-->
<?php include "includes/footer.php";?>