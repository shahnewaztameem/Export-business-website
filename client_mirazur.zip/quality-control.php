<?php include "includes/db.php";?>
<?php include "includes/header.php";?>
<br class="lh2em" />
<div id="middle">
    <div id="bodyFormat1" class="wrap ls">
        <div class="row1 dt columns23">
            <div class="col-2" style="padding-left:0;">
                <!-- header ends -->

                <div class="h1">
                    <h1>Quality Control</h1>
                </div>
                <p class="breadcrumb ar uu small"><a href="<?= BASE_URL?>/" title="Home">Home</a> <b class="ffv p2px">&rsaquo;</b> Quality Control</p>
                <br />
                <div class="bdr dashed p15px">
                    <table class="w100 formTable bdr0">
                        <tr>
                            <td>All our products that we deal in conformity to both domestic in addition to international food standards. Mass Export World is a customer-oriented company and take all efforts to exceed the customer expectations and meet their requirements. Serving quality products to our clients is our utmost priority and owing to the same. Various quality checks carry out under the supervision of our quality control executives. Moreover, rich experience in the concerned field is further helped us in taking relevant steps to avoid the organic products from damage attributable to variations inside the climate of external pollutants.
                            </td>
                        </tr>
                    </table>
                </div><br />
                <!-- footer -->
            </div>
            <!--            sidebar-->
            <?php include "includes/sidebar.php";?>
        </div>
    </div>
</div>
<br />


<?php include "includes/footer.php";?>